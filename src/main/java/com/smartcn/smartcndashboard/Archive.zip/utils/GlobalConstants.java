package com.smartcn.smartcndashboard.utils;

public class GlobalConstants {

	public static final String templateBucketName="pdf-templates-bucket";

	public static final String fileBucketName="ombuck1/files";
}
